from flask import Flask, render_template, request, redirect
from models import db, User, Student, Company, Drive, Application
from config import Config
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)

# ---------------- USER LOADER ----------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------------- CREATE DB ----------------
with app.app_context():
    db.create_all()

    # create admin if not exists
    if not User.query.filter_by(role='admin').first():
        admin = User(
            name="Admin",
            email="admin@gmail.com",
            password=generate_password_hash("admin123"),
            role="admin"
        )
        db.session.add(admin)
        db.session.commit()

# ---------------- HOME ----------------
@app.route('/')
def index():
    return render_template('index.html')

# ---------------- REGISTER ----------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        role = request.form['role']

        # CHECK IF USER EXISTS
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return "User already registered with this email!"

        user = User(name=name, email=email, password=password, role=role)
        db.session.add(user)
        db.session.commit()

        if role == "student":
            student = Student(user_id=user.id)
            db.session.add(student)

        elif role == "company":
            company = Company(user_id=user.id, company_name=name)
            db.session.add(company)

        db.session.commit()
        return redirect('/login')

    return render_template('register.html')


# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()

        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)

            if user.role == 'admin':
                return redirect('/admin')
            elif user.role == 'company':
                return redirect('/company')
            else:
                return redirect('/student')
        else:
            return "Invalid Credentials"

    return render_template('login.html')

# ---------------- LOGOUT ----------------
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

# ---------------- ADMIN DASHBOARD ----------------
@app.route('/admin')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        return "Access Denied"

    students = Student.query.count()
    companies = Company.query.all()
    drives = Drive.query.all()
    applications = Application.query.count()

    return render_template('admin/dashboard.html',
                           students=students,
                           companies=companies,
                           drives=drives,
                           applications=applications)

# ---------------- APPROVE / REJECT COMPANY ----------------
@app.route('/approve_company/<int:id>')
@login_required
def approve_company(id):
    if current_user.role != 'admin':
        return "Access Denied"

    company = Company.query.get(id)
    company.approval_status = "Approved"
    db.session.commit()
    return redirect('/admin')


@app.route('/reject_company/<int:id>')
@login_required
def reject_company(id):
    if current_user.role != 'admin':
        return "Access Denied"

    company = Company.query.get(id)
    company.approval_status = "Rejected"
    db.session.commit()
    return redirect('/admin')

# ---------------- APPROVE / REJECT DRIVE ----------------
@app.route('/approve_drive/<int:id>')
@login_required
def approve_drive(id):
    if current_user.role != 'admin':
        return "Access Denied"

    drive = Drive.query.get(id)
    drive.status = "Approved"
    db.session.commit()
    return redirect('/admin')


@app.route('/reject_drive/<int:id>')
@login_required
def reject_drive(id):
    if current_user.role != 'admin':
        return "Access Denied"

    drive = Drive.query.get(id)
    drive.status = "Rejected"
    db.session.commit()
    return redirect('/admin')

# ---------------- STUDENT DASHBOARD ----------------
@app.route('/student')
@login_required
def student_dashboard():
    if current_user.role != 'student':
        return "Access Denied"
    student = Student.query.filter_by(user_id=current_user.id).first()
    drives = Drive.query.filter_by(status="Approved").all()
    applications = Application.query.filter_by(student_id=student.id).all()

    return render_template('student/dashboard.html',
                       drives=drives,
                       applications=applications)
    
# ---------------- COMPANY DASHBOARD ----------------
@app.route('/company')
@login_required
def company_dashboard():
    if current_user.role != 'company':
        return "Access Denied"

    return render_template('company/dashboard.html')
@app.route('/create_drive', methods=['GET', 'POST'])
@login_required
def create_drive():
    if current_user.role != 'company':
        return "Access Denied"

    company = Company.query.filter_by(user_id=current_user.id).first()

    # only approved companies allowed
    if company.approval_status != "Approved":
        return "Your company is not approved yet"

    if request.method == 'POST':
        job_title = request.form['job_title']
        description = request.form['description']
        eligibility = request.form['eligibility']
        deadline = request.form['deadline']

        drive = Drive(
            company_id=company.id,
            job_title=job_title,
            description=description,
            eligibility=eligibility,
            deadline=deadline,
            status="Pending"   # admin approval needed
        )

        db.session.add(drive)
        db.session.commit()

        return redirect('/company')

    return render_template('company/create_drive.html')
@app.route('/company_drives')
@login_required
def company_drives():
    if current_user.role != 'company':
        return "Access Denied"

    company = Company.query.filter_by(user_id=current_user.id).first()
    drives = Drive.query.filter_by(company_id=company.id).all()

    return render_template('company/view_drives.html', drives=drives)
# ---------------- APPLY FOR DRIVE ----------------
@app.route('/apply/<int:drive_id>')
@login_required
def apply(drive_id):
    if current_user.role != 'student':
        return "Access Denied"

    student = Student.query.filter_by(user_id=current_user.id).first()

    # prevent duplicate application
    existing = Application.query.filter_by(
        student_id=student.id, drive_id=drive_id).first()

    if not existing:
        application = Application(student_id=student.id, drive_id=drive_id)
        db.session.add(application)
        db.session.commit()

    return redirect('/student')
@app.route('/view_applicants/<int:drive_id>')
@login_required
def view_applicants(drive_id):
    if current_user.role != 'company':
        return "Access Denied"

    drive = Drive.query.get(drive_id)

    # join application + student
    applications = Application.query.filter_by(drive_id=drive_id).all()

    return render_template('company/applicants.html',
                           applications=applications,
                           drive=drive)
@app.route('/update_status/<int:app_id>/<status>')
@login_required
def update_status(app_id, status):
    if current_user.role != 'company':
        return "Access Denied"

    application = Application.query.get(app_id)
    application.status = status
    db.session.commit()

    return redirect(request.referrer)
@app.route('/my_applications')
@login_required
def my_applications():
    if current_user.role != 'student':
        return "Access Denied"

    student = Student.query.filter_by(user_id=current_user.id).first()
    applications = Application.query.filter_by(student_id=student.id).all()

    return render_template('student/applications.html',
                           applications=applications)
# ---------------- RUN APP ----------------
if __name__ == '__main__':
    app.run(debug=True)